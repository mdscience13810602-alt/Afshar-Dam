package ir.afshardam.app

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var db: Database
    private lateinit var root: LinearLayout
    private var villageId = -1
    private var farmerId = -1
    private val green = 0xFF176B48.toInt()
    private val cream = 0xFFF7F9F7.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Database(this)
        home()
    }

    private fun page(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(22, 20, 22, 24)
            setBackgroundColor(cream)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        root.addView(TextView(this).apply {
            text = title
            textSize = 23f
            setTextColor(green)
            setPadding(0, 0, 0, 16)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
    }

    private fun action(label: String, run: () -> Unit) {
        root.addView(Button(this).apply {
            text = label; isAllCaps = false; textSize = 16f
            setTextColor(-1); setBackgroundColor(green)
            setOnClickListener { run() }
        }, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, 5, 0, 5)
        })
    }

    private fun input(hint: String, numeric: Boolean = false): EditText {
        return EditText(this).apply {
            this.hint = hint
            textSize = 16f
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER
            root.addView(this)
        }
    }

    private fun label(value: String) {
        root.addView(TextView(this).apply {
            text = value; textSize = 17f; setTextColor(green); setPadding(0, 14, 0, 8)
        })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun home() {
        page("افشار دام")
        root.addView(TextView(this).apply {
            text = "سامانه مدیریت واکسیناسیون دام\nحافظ علیزاده"
            textSize = 16f; setTextColor(green); setPadding(0, 0, 0, 18)
        })
        action("📁 مدیریت روستاها") { villages() }
        action("📊 گزارش و خروجی Excel (CSV)") { exportCsv() }
        action("📄 گزارش PDF") { exportPdf() }
        action("💾 پشتیبان‌گیری از پایگاه داده") { backupDatabase() }
        action("✉️ ارسال خروجی به Gmail یا برنامه دیگر") { shareCsv() }
        label("نسخه ۱.۱ | ذخیره‌سازی آفلاین روی گوشی")
    }

    private fun villages() {
        page("روستاها")
        val name = input("نام روستا")
        val lat = input("عرض جغرافیایی GPS")
        val lon = input("طول جغرافیایی GPS")
        val notes = input("توضیحات روستا")
        action("📍 دریافت موقعیت فعلی") { getGps(lat, lon) }
        action("ذخیره روستا") {
            if (name.text.isBlank()) { toast("نام روستا را وارد کنید"); return@action }
            db.insert("villages", ContentValues().apply {
                put("name", name.text.toString()); put("lat", lat.text.toString())
                put("lon", lon.text.toString()); put("notes", notes.text.toString())
            })
            toast("روستا ذخیره شد"); villages()
        }
        action("بازگشت") { home() }
        label("فهرست روستاهای ثبت‌شده")
        val c = db.query("SELECT id,name,lat,lon FROM villages ORDER BY name")
        while (c.moveToNext()) {
            val id = c.getInt(0)
            action("📂 ${c.getString(1)}  |  ${c.getString(2) ?: ""}, ${c.getString(3) ?: ""}") {
                villageId = id; farmers()
            }
        }
        c.close()
    }

    private fun farmers() {
        page("دامداران")
        val vc = db.query("SELECT name FROM villages WHERE id=$villageId")
        val vn = if (vc.moveToFirst()) vc.getString(0) else ""
        vc.close()
        label("روستا: $vn")
        val name = input("نام و نام خانوادگی دامدار")
        val phone = input("شماره تماس", true)
        val adult = input("تعداد دام بالغ", true)
        val young = input("تعداد دام نابالغ", true)
        val notes = input("توضیحات")
        action("ذخیره دامدار") {
            if (name.text.isBlank()) { toast("نام دامدار را وارد کنید"); return@action }
            db.insert("farmers", ContentValues().apply {
                put("village_id", villageId); put("name", name.text.toString())
                put("phone", phone.text.toString()); put("adult", adult.text.toString().toIntOrNull() ?: 0)
                put("young", young.text.toString().toIntOrNull() ?: 0); put("notes", notes.text.toString())
            })
            toast("دامدار ثبت شد"); farmers()
        }
        action("بازگشت به روستاها") { villages() }
        label("فهرست دامداران")
        val c = db.query("SELECT id,name,phone,adult,young FROM farmers WHERE village_id=$villageId ORDER BY name")
        while (c.moveToNext()) {
            val id = c.getInt(0)
            action("${c.getString(1)} | ${c.getString(2)} | بالغ ${c.getInt(3)}، نابالغ ${c.getInt(4)}") {
                farmerId = id; vaccinations()
            }
        }
        c.close()
    }

    private fun vaccinations() {
        page("ثبت واکسیناسیون")
        val fc = db.query("SELECT name FROM farmers WHERE id=$farmerId")
        val fn = if (fc.moveToFirst()) fc.getString(0) else ""
        fc.close()
        label("دامدار: $fn")
        val animal = input("نوع دام (گاو، گوسفند، بز و...)")
        val vaccine = input("نام واکسن تزریقی")
        val company = input("نام شرکت واکسن")
        val batch = input("شماره بچ واکسن")
        val date = input("تاریخ شمسی")
        date.setText(JalaliDate.today())
        action("📅 انتخاب تاریخ شمسی") {
            val now = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                date.setText(JalaliDate.fromGregorian(y, m + 1, d))
            }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
        }
        val count = input("تعداد دام واکسینه‌شده", true)
        val notes = input("توضیحات")
        action("ثبت واکسیناسیون") {
            if (vaccine.text.isBlank() || date.text.isBlank()) { toast("نام واکسن و تاریخ لازم است"); return@action }
            db.insert("vaccinations", ContentValues().apply {
                put("farmer_id", farmerId); put("animal", animal.text.toString())
                put("vaccine", vaccine.text.toString()); put("company", company.text.toString())
                put("batch", batch.text.toString()); put("date_jalali", date.text.toString())
                put("count", count.text.toString().toIntOrNull() ?: 0); put("notes", notes.text.toString())
            })
            toast("سابقه واکسیناسیون ذخیره شد"); vaccinations()
        }
        action("بازگشت به دامداران") { farmers() }
        label("سوابق ثبت‌شده")
        val c = db.query("SELECT animal,vaccine,company,batch,date_jalali,count,notes FROM vaccinations WHERE farmer_id=$farmerId ORDER BY id DESC")
        while (c.moveToNext()) {
            root.addView(TextView(this).apply {
                text = "نوع دام: ${c.getString(0)}\nواکسن: ${c.getString(1)}\nشرکت: ${c.getString(2)}\nبچ: ${c.getString(3)}\nتاریخ: ${c.getString(4)}\nتعداد واکسینه: ${c.getInt(5)}\nتوضیحات: ${c.getString(6)}\n────────────"
                textSize = 15f; setTextColor(0xFF222222.toInt()); setPadding(4, 10, 4, 10)
            })
        }
        c.close()
    }

    private fun buildCsv(): String {
        val out = StringBuilder("روستا,دامدار,شماره تماس,دام بالغ,دام نابالغ,نوع دام,واکسن,شرکت,شماره بچ,تاریخ شمسی,تعداد واکسینه,توضیحات\n")
        val c = db.query("""SELECT v.name,f.name,f.phone,f.adult,f.young,x.animal,x.vaccine,x.company,x.batch,x.date_jalali,x.count,x.notes
            FROM farmers f JOIN villages v ON f.village_id=v.id
            LEFT JOIN vaccinations x ON x.farmer_id=f.id ORDER BY v.name,f.name""")
        while (c.moveToNext()) {
            val row = (0 until 12).joinToString(",") { i ->
                val value = if (c.isNull(i)) "" else c.getString(i)
                "\"" + value.replace("\"", "\"\"") + "\""
            }
            out.append(row).append('\n')
        }
        c.close()
        return "\uFEFF$out"
    }

    private fun exportCsv() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "AfsharDam-Report.csv")
        }
        csvToSave = buildCsv()
        startActivityForResult(intent, 501)
    }

    private fun shareCsv() {
        val file = File(cacheDir, "AfsharDam-Report.csv")
        file.writeText(buildCsv(), Charsets.UTF_8)
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"; putExtra(Intent.EXTRA_SUBJECT, "گزارش افشار دام")
            putExtra(Intent.EXTRA_TEXT, "گزارش اطلاعات واکسیناسیون دام پیوست شده است.")
            putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "ارسال گزارش با Gmail یا برنامه دیگر"))
    }

    private fun exportPdf() {
        val pdf = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val p = pdf.startPage(pageInfo)
        val paint = Paint().apply { textSize = 13f; color = 0xFF111111.toInt() }
        val lines = buildCsv().removePrefix("\uFEFF").lines()
        var y = 45f
        p.canvas.drawText("Afshar Dam - Livestock Vaccination Report", 30f, y, paint)
        y += 28f
        for (line in lines) {
            if (y > 810f) break
            p.canvas.drawText(line.take(90), 30f, y, paint)
            y += 17f
        }
        pdf.finishPage(p)
        val file = File(cacheDir, "AfsharDam-Report.pdf")
        FileOutputStream(file).use { pdf.writeTo(it) }
        pdf.close()
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "گزارش افشار دام"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "ذخیره، ارسال یا چاپ PDF"))
    }

    private fun backupDatabase() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, "AfsharDam-Backup.db")
        }
        startActivityForResult(intent, 502)
    }

    private fun getGps(lat: EditText, lon: EditText) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 77)
            toast("مجوز مکان را بدهید و دوباره دکمه GPS را بزنید"); return
        }
        try {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            val location: Location? = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (location == null) toast("موقعیت فعلی موجود نیست؛ GPS را روشن کنید")
            else { lat.setText(location.latitude.toString()); lon.setText(location.longitude.toString()) }
        } catch (_: Exception) { toast("دریافت موقعیت انجام نشد") }
    }

    private var csvToSave: String = ""

    @Deprecated("Legacy activity result API used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri: Uri = data.data!!
        try {
            when (requestCode) {
                501 -> contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(csvToSave) }
                502 -> {
                    val dbFile = getDatabasePath("afshardam.db")
                    contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(dbFile).use { it.copyTo(out) } }
                }
            }
            toast("فایل با موفقیت ذخیره شد")
        } catch (e: Exception) { toast("خطا در ذخیره فایل: ${e.message}") }
    }
}
