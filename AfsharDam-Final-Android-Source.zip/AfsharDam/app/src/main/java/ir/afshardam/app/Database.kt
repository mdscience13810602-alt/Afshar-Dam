package ir.afshardam.app

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Database(context: Context) : SQLiteOpenHelper(context, "afshardam.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE villages(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, lat TEXT, lon TEXT, notes TEXT)""")
        db.execSQL("""CREATE TABLE farmers(
            id INTEGER PRIMARY KEY AUTOINCREMENT, village_id INTEGER NOT NULL, name TEXT NOT NULL,
            phone TEXT, adult INTEGER DEFAULT 0, young INTEGER DEFAULT 0, notes TEXT)""")
        db.execSQL("""CREATE TABLE vaccinations(
            id INTEGER PRIMARY KEY AUTOINCREMENT, farmer_id INTEGER NOT NULL, animal TEXT, vaccine TEXT NOT NULL,
            company TEXT, batch TEXT, date_jalali TEXT NOT NULL, count INTEGER DEFAULT 0, notes TEXT)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun insert(table: String, values: ContentValues) = writableDatabase.insert(table, null, values)
    fun query(sql: String, args: Array<String>? = null): Cursor = readableDatabase.rawQuery(sql, args)
}
