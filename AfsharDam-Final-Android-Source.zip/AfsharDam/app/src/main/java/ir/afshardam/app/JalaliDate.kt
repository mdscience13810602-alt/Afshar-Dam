package ir.afshardam.app

import java.util.Calendar

// Gregorian-to-Jalali conversion; the Android date picker remains the date-selection UI.
object JalaliDate {
    fun fromGregorian(gy0: Int, gm: Int, gd: Int): String {
        val gdm = intArrayOf(0,31, if (isLeapGregorian(gy0)) 29 else 28,31,30,31,30,31,31,30,31,30,31)
        var gy = gy0 - 1600
        var gm0 = gm - 1
        var gd0 = gd - 1
        var gDayNo = 365 * gy + (gy + 3) / 4 - (gy + 99) / 100 + (gy + 399) / 400
        for (i in 0 until gm0) gDayNo += gdm[i]
        gDayNo += gd0
        var jDayNo = gDayNo - 79
        val jNp = jDayNo / 12053
        jDayNo %= 12053
        var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
        jDayNo %= 1461
        if (jDayNo >= 366) {
            jy += (jDayNo - 1) / 365
            jDayNo = (jDayNo - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (jDayNo < 186) {
            jm = 1 + jDayNo / 31
            jd = 1 + jDayNo % 31
        } else {
            jm = 7 + (jDayNo - 186) / 30
            jd = 1 + (jDayNo - 186) % 30
        }
        return "%04d/%02d/%02d".format(jy, jm, jd)
    }
    private fun isLeapGregorian(y: Int) = y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)
    fun today(): String {
        val c = Calendar.getInstance()
        return fromGregorian(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }
}
